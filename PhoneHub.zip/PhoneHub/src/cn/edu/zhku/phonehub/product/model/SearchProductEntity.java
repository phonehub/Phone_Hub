package cn.edu.zhku.phonehub.product.model;

public class SearchProductEntity {

	private String searchType;
	private String searchInfo;
	
	public SearchProductEntity() {
		super();
	}

	public String getSearchType() {
		return searchType;
	}

	public void setSearchType(String searchType) {
		this.searchType = searchType;
	}

	public String getSearchInfo() {
		return searchInfo;
	}

	public void setSearchInfo(String searchInfo) {
		this.searchInfo = searchInfo;
	}
	
	
}
